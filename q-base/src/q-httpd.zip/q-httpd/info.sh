#!/bin/bash

/bin/cat << EOM
<html>
 <head>
  <title> QHTTPD SERVER INFO </title>
 </head>
 <body>
<b>
uname -a
</b>
<pre>
EOM
uname -a
/bin/cat << EOM
</pre>
<br/>
<b>
ps -eaf | grep qhttpd
</b>
<pre>
EOM
ps -eaf | grep qhttpd
/bin/cat << EOM
<pre>
 </body>
</html>
EOM
