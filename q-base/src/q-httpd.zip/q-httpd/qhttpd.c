#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <ctype.h>
#include <strings.h>
#include <string.h>
#include <sys/stat.h>
#include <pthread.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <time.h>
#include <netinet/tcp.h>

#define ISspace(x) isspace((int)(x))

#define SERVER_STRING "Server: qhttpd/0.1.0\r\n"

#define SERVER_PORT 8000

#define SERVER_REQ_Q 1000

void accept_request(int*);
void bad_request(int);
void cat(int, FILE *);
void cannot_execute(int);
void error_die(const char *);
int get_line(int, char *, int);
void headers(int, const char *);
void not_found(int);
void serve_file(int, const char *);
int startup(u_short *);
void unimplemented(int);
void process_get(char *, char *, char *, char *, int);
void send_server_info(int);
//void execute_plugin(char *, char *, int); 
void execute_plugin(char *, char *, int, int); 
void execute_q_query(char *, int);
int csv_to_json(char *, char *);
void split_query_str(char *, char *);
void generate_namespace(char *);
void send_identifier(char *, int);
int valid_qid(char *, char *, char *, int *);
void send_invalid_req(int);
int find_namespace_map_indx(char *);
void acquire_namespace(int);
void release_namespace(int);

typedef struct {
 char id[16];
 char q_root[256];
 char q_data[256];
 char q_alt_data[256];
 int busy;
} st_namespace_map;

st_namespace_map namespace_map[SERVER_REQ_Q];
int namespace_map_count = 0;
pthread_mutex_t namespace_map_lock;

void split_query_str(char *src, char *dest)
{
 unsigned int i;
 for(i = 0; i < strlen(src); i++)
 {
  if(src[i] == '&')
   dest[i] = ' ';
  else
   dest[i] = src[i];
 }
 dest[i] = '\0';
}

void send_server_info(int client)
{
 char tempfile[L_tmpnam + 10]; //  concatenating thread_id 
 char cmd[sizeof(tempfile) + 16]; // 16 is for extra chars and command name

 fprintf(stderr, "sending server info\n");

 memset(&tempfile, 0, sizeof(tempfile));
 sprintf(tempfile, "%s_%u", tmpnam(tempfile), (unsigned int) (pthread_self()));

 fprintf(stderr, "temp filename = %s\n", tempfile);

 sprintf(cmd, "./info.sh > %s", tempfile); 
 fprintf(stderr, "cmd = %s\n", cmd);

 if(system(cmd) != 0)
 {
  fprintf(stderr, "error getting server info\n");
 }
 else
 {
   serve_file(client, tempfile);
   remove(tempfile);
 }
}

void acquire_namespace(int ns_map_indx)
{

 //TODO: setup environment variables for Q here
 
 fprintf(stderr, "acquiring namespace\n");
 init:
 pthread_mutex_lock(&namespace_map_lock);

 if(namespace_map[ns_map_indx].busy == 0)
 {
  namespace_map[ns_map_indx].busy=1;
  pthread_mutex_unlock(&namespace_map_lock);
 }
 else
 {
  pthread_mutex_unlock(&namespace_map_lock);
  fprintf(stderr, "namespace busy, waiting for 1 sec\n");
  sleep(1);
  goto init; 
 }
 fprintf(stderr, "namepace acquired\n");
}

void release_namespace(int ns_map_indx)
{
 pthread_mutex_lock(&namespace_map_lock);
 namespace_map[ns_map_indx].busy=0;
 pthread_mutex_unlock(&namespace_map_lock);
 fprintf(stderr, "namepace released \n");
}

//void execute_plugin(char *path, char *query_string, int client)
void execute_plugin(char *path, char *query_string, int client, int ns_map_indx)
{
 char tempfile[L_tmpnam + 10]; // 10 concatenating thread_id 
 char cmd[sizeof(tempfile) + strlen(path) + strlen(query_string) + 8]; // 8 for extra spaces and all
 char query_string_new[strlen(query_string)]; // to store query string split by space

 fprintf(stderr, "executing plugin\n");

 memset(&tempfile, 0, sizeof(tempfile));
 sprintf(tempfile, "%s_%u", tmpnam(tempfile), (unsigned int) (pthread_self()));
 
 fprintf(stderr, "temp filename = %s\n", tempfile);

 split_query_str(query_string, query_string_new);
 sprintf(cmd, "%s %s > %s", path, query_string_new, tempfile); 
 fprintf(stderr, "cmd = %s\n", cmd);

 // setup namespace and wait if another thread is executing on the same namespace
 acquire_namespace(ns_map_indx);

 if(system(cmd) != 0)
 {
  fprintf(stderr, "error executing Q plugin\n");
  release_namespace(ns_map_indx);
 }
 else
 {
   release_namespace(ns_map_indx);
   char tempfile_json[sizeof(tempfile) + 5]; // 5 for .json extension
   csv_to_json(tempfile, tempfile_json);
   sprintf(tempfile_json, "%s.json", tempfile);
   //TODO: uncomment this once csv_to_json is implemented: serve_file(client, tempfile_json);
   serve_file(client, tempfile);
   remove(tempfile);
   remove(tempfile_json);
 }
}

void execute_q_query(char *query_string, int client)
{
 fprintf(stderr, "executing q query\n");
}


int csv_to_json(char *inpfile, char *outfile)
{
 //TODO: write code to convert a file into json file
 fprintf(stderr, "converting csv output to json output\n");
 return 0;
}

void generate_namespace(char *buf)
{
 time_t cur_time;
 cur_time = time(NULL);
 sprintf(buf, "%ju", (uintmax_t)cur_time);
 int cur_namespace_map_indx = 0;

 pthread_mutex_lock(&namespace_map_lock);

 cur_namespace_map_indx = namespace_map_count;
 namespace_map_count++;

 strcpy(namespace_map[cur_namespace_map_indx].id, buf);
 sprintf(namespace_map[cur_namespace_map_indx].q_root, "/tmp/q_root_%s", buf);
 sprintf(namespace_map[cur_namespace_map_indx].q_data, "/tmp/q_data_%s", buf);
 namespace_map[cur_namespace_map_indx].busy=0;

 pthread_mutex_unlock(&namespace_map_lock);

 // remove q root/data directory
 char cmd[64];
 sprintf(cmd, "rm -rf %s", namespace_map[cur_namespace_map_indx].q_root);
 system(cmd);
 sprintf(cmd, "rm -rf %s", namespace_map[cur_namespace_map_indx].q_data);
 system(cmd);

 // create q root/data directory with rwx to u, rwx to g and rx to o
 mkdir(namespace_map[cur_namespace_map_indx].q_root, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
 mkdir(namespace_map[cur_namespace_map_indx].q_data, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
}

void send_identifier(char *id_buf, int client)
{
 char buf[1024];
 char tbuf[1024];

 sprintf(buf, "HTTP/1.1 200 OK\r\n");
 send(client, buf, strlen(buf), 0);

 sprintf(buf, SERVER_STRING);
 send(client, buf, strlen(buf), 0);

 sprintf(buf, "Content-Type: application/json\r\n");
 send(client, buf, strlen(buf), 0);

 sprintf(tbuf, "{ \"id\" : \"%s\"}", id_buf);
 sprintf(buf, "Content-Length: %d\r\n", strlen(tbuf));
 send(client, buf, strlen(buf), 0);

 sprintf(buf, "\r\n");
 send(client, buf, strlen(buf), 0);

 sprintf(buf, "{ \"id\" : \"%s\"}", id_buf);
 send(client, buf, strlen(buf), 0);

 fprintf(stderr, "sending identifier=%s done\n", id_buf);
}

int find_namespace_map_indx(char *id_buf)
{
 int iter = 0;
 for(iter = 0; iter < namespace_map_count; iter++)
 {
  if (strcmp(namespace_map[iter].id, id_buf) == 0)
  {
   return iter;
  }
 }

 return -1;
}

int valid_qid(char *query_string, char *id_buf, char *query_string_no_qid, int *map_indx)
{
 char *c = NULL;
 int indx = 0;

 // look for qid
 c = strstr(query_string, "qid=");
 if(c == NULL)
 {
  return 0;
 }
 else
 {
  // found qid, make sure is it not part of another query paramter
  // check if it's the start
  if(c == query_string)
  {
   c += 4; // take 4 chars ahead qid=
   while(*c != '&')
   {
    id_buf[indx++] = *c;
    c++;
   }
   id_buf[indx] = '\0';
   strcpy(query_string_no_qid, c+1);
  }
  // check if the previous char is &
  else if (*(c-1) == '&') 
  {
   // find len of first part of qs before qid
   int len_part1 = abs(c - query_string);
   // copy first part
   strncpy(query_string_no_qid, query_string, len_part1);

   c += 4; // take 4 chars ahead qid=
   while(*c != '&')
   {
    id_buf[indx++] = *c;
    c++;
   }
   strcpy(query_string_no_qid + len_part1, c+1);
  }
  else
  {
   return 0;
  }
 }

 fprintf(stderr, "query_string_no_qid = %s\n", query_string_no_qid);
 fprintf(stderr, "qid = %s\n", id_buf); 

 // now check if the qid is actually present in the namespace or not
 *map_indx = find_namespace_map_indx(id_buf);
 if(*map_indx == -1)
 {
  fprintf(stderr, "not a valid Q identifier\n");
  return 0;
 }

 return 1;
}

void process_get(char *path, char *query_string, char *method, char *url, int client)
{
 char buf[1024];
 int numchars;
 struct stat st;
 char id_buf[16];
 char query_string_no_qid[strlen(query_string)];
 int map_indx = -1;

 fprintf(stderr, "path = %s\n", path);
 fprintf(stderr, "query = %s\n", query_string);
 fprintf(stderr, "method = %s\n", method);
 fprintf(stderr, "url = %s\n", url);

 if (strcasecmp(url, "/qidentifier") == 0)
 {
  generate_namespace(id_buf);
  send_identifier(id_buf, client);
 }
 else if (strcasecmp(url, "/info") == 0)
 {
  send_server_info(client);
 }
 else if (strncasecmp(url, "/plugins/", 9) == 0)
 {
  if(valid_qid(query_string, id_buf, query_string_no_qid, &map_indx))
  {
   //execute_plugin(path, query_string, client); 
   execute_plugin(path, query_string_no_qid, client, map_indx); 
  }
  else
  {
   send_invalid_req(client);
  }
 }
 else if (strcasecmp(url, "/q") == 0)
 {
  execute_q_query(query_string, client);
 }
 else
 {
  if (stat(path, &st) == -1) {
   while ((numchars > 0) && strcmp("\n", buf))  /* read & discard headers */
   { 
     numchars = get_line(client, buf, sizeof(buf));
     fprintf(stderr, "request line to discard = %s\n", buf);
   } 
   not_found(client);
  } 
  else
  {
    serve_file(client, path);
  }
 }
}

/**********************************************************************/
/* A request has caused a call to accept() on the server port to
 * return.  Process the request appropriately.
 * Parameters: the socket connected to the client */
/**********************************************************************/
void accept_request(int *client_sock)
{
 int client = *client_sock;
 char buf[1024];
 int numchars;
 char method[255];
 char url[255];
 char path[512];
 size_t i, j;
 char *query_string = NULL;

 fprintf(stderr, "===================================================\n");
 numchars = get_line(client, buf, sizeof(buf));
 fprintf(stderr, "request line = %s\n", buf);
 fflush(stderr);
 i = 0; j = 0;
 while (!ISspace(buf[j]) && (i < sizeof(method) - 1))
 {
  method[i] = buf[j];
  i++; j++;
 }
 method[i] = '\0';

 if (strcasecmp(method, "GET") != 0)
 {
  unimplemented(client);
 }

 i = 0;
 while (ISspace(buf[j]) && (j < sizeof(buf)))
  j++;
 while (!ISspace(buf[j]) && (i < sizeof(url) - 1) && (j < sizeof(buf)))
 {
  url[i] = buf[j];
  i++; j++;
 }
 url[i] = '\0';

 if (strcasecmp(method, "GET") == 0)
 {
  query_string = url;
  while ((*query_string != '?') && (*query_string != '\0'))
   query_string++;
  if (*query_string == '?')
  {
   *query_string = '\0';
   query_string++;
  }
 }

 sprintf(path, ".%s", url);
 if (path[strlen(path) - 1] == '/')
  strcat(path, "index.html");

 fflush(stderr);
 process_get(path, query_string, method, url, client);

 close(client);

 fprintf(stderr, "===================================================\n");
}

/**********************************************************************/
/* Inform the client that a request it has made has a problem.
 * Parameters: client socket */
/**********************************************************************/
void bad_request(int client)
{
 char buf[1024];

 sprintf(buf, "HTTP/1.0 400 BAD REQUEST\r\n");
 send(client, buf, sizeof(buf), 0);
 sprintf(buf, "Content-type: text/html\r\n");
 send(client, buf, sizeof(buf), 0);
 sprintf(buf, "\r\n");
 send(client, buf, sizeof(buf), 0);
 sprintf(buf, "<P>Your browser sent a bad request, ");
 send(client, buf, sizeof(buf), 0);
 sprintf(buf, "such as a POST without a Content-Length.\r\n");
 send(client, buf, sizeof(buf), 0);
}

/**********************************************************************/
/* Put the entire contents of a file out on a socket.  This function
 * is named after the UNIX "cat" command, because it might have been
 * easier just to do something like pipe, fork, and exec("cat").
 * Parameters: the client socket descriptor
 *             FILE pointer for the file to cat */
/**********************************************************************/
void cat(int client, FILE *resource)
{
 char buf[1024];

 fgets(buf, sizeof(buf), resource);
 while (!feof(resource))
 {
  send(client, buf, strlen(buf), 0);
  fgets(buf, sizeof(buf), resource);
 }
}

/**********************************************************************/
/* Inform the client that a CGI script could not be executed.
 * Parameter: the client socket descriptor. */
/**********************************************************************/
void cannot_execute(int client)
{
 char buf[1024];

 sprintf(buf, "HTTP/1.0 500 Internal Server Error\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "Content-type: text/html\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<P>Error prohibited CGI execution.\r\n");
 send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/* Print out an error message with perror() (for system errors; based
 * on value of errno, which indicates system call errors) and exit the
 * program indicating an error. */
/**********************************************************************/
void error_die(const char *sc)
{
 perror(sc);
 exit(1);
}

/**********************************************************************/
/* Get a line from a socket, whether the line ends in a newline,
 * carriage return, or a CRLF combination.  Terminates the string read
 * with a null character.  If no newline indicator is found before the
 * end of the buffer, the string is terminated with a null.  If any of
 * the above three line terminators is read, the last character of the
 * string will be a linefeed and the string will be terminated with a
 * null character.
 * Parameters: the socket descriptor
 *             the buffer to save the data in
 *             the size of the buffer
 * Returns: the number of bytes stored (excluding null) */
/**********************************************************************/
int get_line(int sock, char *buf, int size)
{
 int i = 0;
 char c = '\0';
 int n;

 while ((i < size - 1) && (c != '\n'))
 {
  n = recv(sock, &c, 1, 0);
  /* DEBUG printf("%02X\n", c); */
  if (n > 0)
  {
   if (c == '\r')
   {
    n = recv(sock, &c, 1, MSG_PEEK);
    /* DEBUG printf("%02X\n", c); */
    if ((n > 0) && (c == '\n'))
     recv(sock, &c, 1, 0);
    else
     c = '\n';
   }
   buf[i] = c;
   i++;
  }
  else
   c = '\n';
 }
 buf[i] = '\0';
 
 return(i);
}

/**********************************************************************/
/* Return the informational HTTP headers about a file. */
/* Parameters: the socket to print the headers on
 *             the name of the file */
/**********************************************************************/
void headers(int client, const char *filename)
{
 char buf[1024];
 (void)filename;  /* could use filename to determine file type */

 strcpy(buf, "HTTP/1.1 200 OK\r\n");
 send(client, buf, strlen(buf), 0);
 strcpy(buf, SERVER_STRING);
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "Content-Type: text/html\r\n");
 send(client, buf, strlen(buf), 0);
 strcpy(buf, "\r\n");
 send(client, buf, strlen(buf), 0);
}


void send_invalid_req(int client)
{
 char buf[1024];

 sprintf(buf, "HTTP/1.0 400 Bad Request\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, SERVER_STRING);
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "Content-Type: text/html\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<HTML><TITLE>Bad Request</TITLE>\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<BODY><P>The server could not fulfill\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "your request because the Q identifier is invalid\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "or missing.\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "</BODY></HTML>\r\n");
 send(client, buf, strlen(buf), 0);
}
/**********************************************************************/
/* Give a client a 404 not found status message. */
/**********************************************************************/
void not_found(int client)
{
 char buf[1024];

 sprintf(buf, "HTTP/1.0 404 NOT FOUND\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, SERVER_STRING);
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "Content-Type: text/html\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<HTML><TITLE>Not Found</TITLE>\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<BODY><P>The server could not fulfill\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "your request because the resource specified\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "is unavailable or nonexistent.\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "</BODY></HTML>\r\n");
 send(client, buf, strlen(buf), 0);
}

/**********************************************************************/
/* Send a regular file to the client.  Use headers, and report
 * errors to client if they occur.
 * Parameters: a pointer to a file structure produced from the socket
 *              file descriptor
 *             the name of the file to serve */
/**********************************************************************/
void serve_file(int client, const char *filename)
{
 FILE *resource = NULL;
 int numchars = 1;
 char buf[1024];

 buf[0] = 'A'; buf[1] = '\0';
 while ((numchars > 0) && strcmp("\n", buf))  /* read & discard headers */
  numchars = get_line(client, buf, sizeof(buf));

 resource = fopen(filename, "r");
 if (resource == NULL)
  not_found(client);
 else
 {
  headers(client, filename);
  cat(client, resource);
 }
 fclose(resource);
}

/**********************************************************************/
/* This function starts the process of listening for web connections
 * on a specified port.  If the port is 0, then dynamically allocate a
 * port and modify the original port variable to reflect the actual
 * port.
 * Parameters: pointer to variable containing the port to connect on
 * Returns: the socket */
/**********************************************************************/
int startup(u_short *port)
{
 int httpd = 0;
 struct sockaddr_in name;

 httpd = socket(PF_INET, SOCK_STREAM, 0);
 if (httpd == -1)
  error_die("socket");
 memset(&name, 0, sizeof(name));
 name.sin_family = AF_INET;
 name.sin_port = htons(*port);
 name.sin_addr.s_addr = htonl(INADDR_ANY);
 if (bind(httpd, (struct sockaddr *)&name, sizeof(name)) < 0)
  error_die("bind");

 if (listen(httpd, SERVER_REQ_Q) < 0)
  error_die("listen");
 return(httpd);
}

/**********************************************************************/
/* Inform the client that the requested web method has not been
 * implemented.
 * Parameter: the client socket */
/**********************************************************************/
void unimplemented(int client)
{
 char buf[1024];

 sprintf(buf, "HTTP/1.0 501 Method Not Implemented\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, SERVER_STRING);
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "Content-Type: text/html\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<HTML><HEAD><TITLE>Method Not Implemented\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "</TITLE></HEAD>\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "<BODY><P>HTTP request method not supported.\r\n");
 send(client, buf, strlen(buf), 0);
 sprintf(buf, "</BODY></HTML>\r\n");
 send(client, buf, strlen(buf), 0);
}

/**********************************************************************/

int main(void)
{
 int server_sock = -1;
 u_short port = SERVER_PORT;
 int client_sock = -1;
 struct sockaddr_in client_name;
 socklen_t client_name_len = sizeof(client_name);

 server_sock = startup(&port);

 if(pthread_mutex_init(&namespace_map_lock, NULL) != 0)
 {
  fprintf(stderr, "mutex init failed\n");
  error_die("mutex_init");
 }

#ifdef THREADED
 printf("httpd running on port %d in multi threaded mode!\n", port);
#else
 printf("httpd running on port %d in single thread mode!\n", port);
#endif

 while (1)
 {
  client_sock = accept(server_sock,
                       (struct sockaddr *)&client_name,
                       &client_name_len);

  int flag=1;
  setsockopt(client_sock, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
  if (client_sock == -1)
   error_die("accept");

#ifdef THREADED
 pthread_t newthread;
 if (pthread_create(&newthread , NULL, (void *)accept_request, &client_sock) != 0)
   perror("pthread_create");
#else
 accept_request(&client_sock);
#endif

 }

 close(server_sock);

 return(0);
}
